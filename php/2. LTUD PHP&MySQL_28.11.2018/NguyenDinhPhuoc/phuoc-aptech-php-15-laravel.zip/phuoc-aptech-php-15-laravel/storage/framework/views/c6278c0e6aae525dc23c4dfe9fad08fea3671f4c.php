<?php $__env->startSection('tittle','Show User'); ?>
<?php $__env->startSection('page-description','SHOW PAGE'); ?>
<?php $__env->startSection('table'); ?>
<table class="table table-hover table-bordered">
  <thead class="">
    <tr class="text-center">
      <th scope="col" class="">#</th>
      <th scope="col" class="">Name</th>
      <th scope="col" class="">Email</th>
      <th scope="col" class="">Password</th>
      <th scope="col" class="">Created Date</th>
      <th scope="col" class="">Updated Date</th>
      <th scope="col" class="">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr class="text-center">
      <th scope="row"><?php echo e($users->id); ?></th>
      <td><?php echo e($users->name); ?> </td>
      <td><?php echo e($users->email); ?></td>
      <td><?php echo e($users->password); ?></td>
      <td><?php echo e($users->created_at); ?></td>
      <td><?php echo e($users->updated_at); ?></td>
      <td class="d-flex border-0 align-items-center justify-content-around">
        <form action="<?php echo e(route('users.edit',$users->id)); ?>" method="get"><button class="btn btn-sm btn-warning mx-2 rounded-0">Edit</button></form>
        <form action="<?php echo e(route('users.destroy',$users->id)); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

          <button class="btn btn-sm btn-danger mx-2 rounded-0">Delete</button></form>
      </td>
    </tr>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>