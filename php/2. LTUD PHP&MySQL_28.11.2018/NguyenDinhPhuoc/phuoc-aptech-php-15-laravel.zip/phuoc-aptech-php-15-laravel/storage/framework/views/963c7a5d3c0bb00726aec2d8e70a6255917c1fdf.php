<?php $__env->startSection('tittle','Edit User'); ?>
<?php $__env->startSection('page-description','EDIT PAGE'); ?>
<?php $__env->startSection('table'); ?>
<form action="<?php echo e(asset($users->id.'/edit')); ?>" method="POST">
  <div class="form-group">
    <label class="text-uppercase font-weight-bold" for="name">name</label>
    <input type="text" class="form-control rounded-0" id="name" placeholder="Name" name="name" value="<?php echo e($users->name); ?>">
  </div>
  <div class="form-group">
    <label class="text-uppercase font-weight-bold" for="email">email</label>
    <input type="email" class="form-control rounded-0" id="email" placeholder="Email" name="email" value="<?php echo e($users->email); ?>">
  </div>

  <div class="form-group">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>

    <button type="submit" class="btn btn-warning text-uppercase rounded-0 font-weight-bold">
      save
    </button>

  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>