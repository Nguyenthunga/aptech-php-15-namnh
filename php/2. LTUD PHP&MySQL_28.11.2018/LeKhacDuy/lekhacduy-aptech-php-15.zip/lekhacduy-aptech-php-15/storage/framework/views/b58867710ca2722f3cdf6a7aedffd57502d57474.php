 
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-12">
      <h3 class="text-uppercase">show page</h3>
      <table class="table table-hover table-bordered">
        <thead class="">
          <tr class="text-center">
            <th scope="col" class="">#</th>
            <th scope="col" class="">Name</th>
            <th scope="col" class="">Email</th>
            <th scope="col" class="">Password</th>
            <th scope="col" class="">Created Date</th>
            <th scope="col" class="">Updated Date</th>
            <th scope="col" class="">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr class="text-center">
            <th scope="row"><?php echo e($user->id); ?></th>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->password); ?></td>
            <td><?php echo e($user->created_at); ?></td>
            <td><?php echo e($user->updated_at); ?></td>
            <td class="d-flex border-0 align-items-center">
              <form action="<?php echo e(route('users.edit',$user->id)); ?>" method="get">
                <button class="btn btn-sm btn-warning mx-2 rounded-0">
                  Edit
                </button>
              </form>
              <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="post">
                <input type="hidden" name="_method" value="delete" /> <?php echo e(csrf_field()); ?>

                <button class="btn btn-sm btn-danger mx-2 rounded-0">
                  Delete
                </button>
              </form>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>