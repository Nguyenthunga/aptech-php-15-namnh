<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    
</head>
<body>
    
<?php $__env->startSection('table'); ?>
<table class="table table-bordered table-hover">
    <thead>
        <tr class="text-center">
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center">
            <th scope="row"><?php echo e($user->id); ?></th>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td class="d-flex justify-content-around align-items-center">
                <form action="<?php echo e($user->id); ?>" method="get"><button class="btn btn-sm btn-primary rounded-0">Show</button>
                </form>
                <form action="<?php echo e($user->id.'/edit'); ?>" method="get"><button class="btn btn-sm btn-warning rounded-0">Edit</button>
                </form>
                <form action="<?php echo e($user->id.'/delete'); ?>" method="get"><button class="btn btn-sm btn-danger rounded-0">Delete</button></form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="d-flex justify-content-center">
        <ul class="pagination">
            <li class="page-item"><a class="page-link" href="<?php echo e($users->url(1)); ?>" rel="prev">Prev</a></li>
    
            <?php for($i=1;$i<=$users->lastPage();$i++): ?>
                <li class="page-item <?php if($users->currentPage()===$i): ?> <?php echo e('active'); ?> <?php endif; ?>)">
                    <a class="page-link" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a></li>
                <?php endfor; ?>
    
                <li class="page-item"><a class="page-link" href="<?php echo e($users->url($users->lastPage())); ?>" rel="next">Next</a></li>
        </ul>
    </div
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>